import React from 'react';
import { DataGrid, GridColDef, GridRowData } from '@material-ui/data-grid';
import httpService from '../../shared/services/httpService';
import urls from '../../shared/services/urls';
import { IProduct } from '../../shared/models/product';
import { makeStyles, Typography } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
    text: {
        marginTop: theme.spacing(2),
        marginBottom: theme.spacing(2),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'left'
    }
}));

const ProductsData: React.FC<ProductsDataProps> = () => {

    const classes = useStyles();

    const [products, setProducts] = React.useState<GridRowData[]>([]);

    const columns: GridColDef[] = [
        { field: 'id', headerName: 'ID', width: 100 },
        { field: 'name', headerName: 'Name', width: 130 },
        { field: 'barcode', headerName: 'BarCode', width: 200 },
        { field: 'description', headerName: 'Description', width: 200 },
        { field: 'rate', headerName: 'Rate', type: 'number', width: 120 },
        { field: 'addedOn', headerName: 'Added On', type: 'dateTime', width: 200 },
        { field: 'modifiedOn', headerName: 'Modified On', type: 'dateTime', width: 200 },
    ];

    React.useEffect(() => {
        httpService.get<IProduct[]>(urls.getProducts()).then(response => {
            setProducts(response.data || []);
        });
    }, []);

    return (
        <React.Fragment>
            <Typography variant='h4' className={classes.text}>Product Catalogue</Typography>
            <div style={{ height: 400, width: '100%' }}>
                <DataGrid rows={products} columns={columns} pageSize={5} checkboxSelection />
            </div>
        </React.Fragment>
    );
};

interface ProductsDataProps {
}

export default ProductsData;
