import { Container } from '@material-ui/core';
import React from 'react';
import { AppContext } from '../../contextAndRoutes/appContext';
import ProductsData from '../product/productsData';
import { useHistory } from 'react-router-dom';
import Routes from '../../contextAndRoutes/routes';

const Homepage = () => {

    const { state } = React.useContext(AppContext);
    const history = useHistory();

    if (!state.userInfo) {
        //history.push(Routes.signin);
    }

    return (
        <React.Fragment>
            <Container>
                <ProductsData />
            </Container>
        </React.Fragment>
    );
};

export default Homepage;
