import { BrowserRouter } from 'react-router-dom';
import { AppProvider } from './contextAndRoutes/appContext';
import ErrorBoundary from './error/errorBoundary';
import RouteConfig from './contextAndRoutes/routeConfig';
import Header from './main/header/header';
import Footer from './main/footer/footer';
import { Box } from '@material-ui/core';
import httpService from './shared/services/httpService';

function App() {

  httpService.configuration();

  return (
    <BrowserRouter>
      <AppProvider>
        <Header />
        <ErrorBoundary>
          <Box minHeight='480px'>
            <RouteConfig />
          </Box>
        </ErrorBoundary>
        <Footer />
      </AppProvider>
    </BrowserRouter>
  );
}

export default App;
