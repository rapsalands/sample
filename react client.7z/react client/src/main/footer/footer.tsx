import { AppBar, makeStyles, Toolbar, Typography } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    title: {
        flexGrow: 1,
        fontSize: '12px'
    },
}));

const Footer = () => {

    const classes = useStyles();

    return (
        <AppBar position="static" color="transparent">
            <Toolbar>
                <Typography variant="h6" className={classes.title}>
                    © {(new Date()).getFullYear()} Demo App
                </Typography>
            </Toolbar>
        </AppBar>
    );
};

export default Footer;
