import { AppBar, Button, createStyles, makeStyles, Theme, Toolbar, Typography } from '@material-ui/core';
import { withRouter } from "react-router-dom";
import Routes from '../../contextAndRoutes/routes';
import { useHistory } from 'react-router-dom';
import { AppContext } from '../../contextAndRoutes/appContext';
import { useContext, Fragment } from 'react';

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            flexGrow: 1,
        },
        menuButton: {
            marginRight: theme.spacing(2),
        },
        title: {
            flexGrow: 1,
            cursor: 'pointer'
        },
        signout: {
            fontSize: '12px',
            cursor: 'pointer'
        },
        space: {
            marginRight: theme.spacing(1)
        }
    }),
);

const Header = (props) => {

    const history = useHistory();
    const classes = useStyles();
    const { state, dispatch } = useContext(AppContext);

    const navigate = (url: string): void => history.push(url);

    const SignInSection = () => {

        const path = props.location.pathname.slice(1);
        const onSigninPage = Routes.signin === `/${path}`;

        if (onSigninPage) return null;

        if (state.userInfo) {

            const signOutOnClick = (e: any) => {
                dispatch({
                    type: 'signin',
                    data: null
                });

                navigate(Routes.signin);
            }

            return (
                <Fragment>
                    <Typography variant="h6" className={classes.space}>
                        {state.userInfo.firstName} {state.userInfo.lastName}
                    </Typography>
                    <Typography onClick={signOutOnClick} variant="h6" className={`${classes.signout} ${classes.space}`}>Sign Out</Typography>
                </Fragment>
            );
        }

        return <Button onClick={() => navigate(Routes.signin)} color="inherit">Sign In</Button>;
    }

    return (
        <AppBar position="static">
            <Toolbar>
                <Typography onClick={() => navigate(Routes.home)} variant="h6" className={classes.title}>
                    Demo App
                </Typography>
                <SignInSection />
            </Toolbar>
        </AppBar>);
};

export default withRouter(Header);
