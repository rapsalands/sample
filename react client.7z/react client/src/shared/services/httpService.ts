import axios from 'axios';

function get<T = any>(url: string): Promise<IPromiseReturn<T>> {
    return axios.get<T>(url);
}

function post<T = any>(url: string, data: any): Promise<IPromiseReturn<T>> {
    return axios.post(url, data);
}

function put<T = any>(url: string, data: any): Promise<IPromiseReturn<T>> {
    return axios.put(url, data);
}

function deleteCall<T = any>(url: string): Promise<IPromiseReturn<T>> {
    return axios.delete(url);
}

function configuration() {

    function error(err) {
        if (err.response.status === 404) {
            // Log if needed.
            console.log(`${err.config.url} not found.`);
        }
        // Log if needed.
        console.log(`${err.config.url} failed.`);
        return err;
    }

    axios.interceptors.response.use(res => res, error);

    axios.defaults.withCredentials = false;
}

const httpService = { get, post, deleteCall, put, configuration };

interface IPromiseReturn<T> {
    data: T
}

export default httpService;
