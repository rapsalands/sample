const { REACT_APP_API_URL } = process.env;

const baseUrl = REACT_APP_API_URL;

const urls = {
    getProduct: (id: number) => `${baseUrl}api/product/${id}`,
    getProducts: () => `${baseUrl}api/product`,
    updateProduct: () => `${baseUrl}api/product`,
    deleteProduct: () => `${baseUrl}api/product`,
    createProduct: () => `${baseUrl}api/product`,
    temp: () => `${baseUrl}guerhgiuegnueih`,
};

export default urls;
