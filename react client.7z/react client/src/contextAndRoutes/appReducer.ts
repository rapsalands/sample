import { DispatchParamType, InitialState } from './contextInterfaces';

const appReducer = (state: InitialState, action: DispatchParamType): InitialState => {
    switch (action.type) {
        case 'signin':
            return { ...state, userInfo: action.data };
        default:
            return state;
    }
}

export default appReducer;
