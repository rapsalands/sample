const Routes = {
    home: "/",
    signin: "/signin",
    error: "/error",
};

export default Routes;
