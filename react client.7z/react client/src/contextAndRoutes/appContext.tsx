import React, { useReducer } from 'react';
import { IAppProviderProps, ICreateContext, InitialState } from './contextInterfaces';
import appReducer from './appReducer';

const AppContext = React.createContext({} as ICreateContext);

const AppProvider: React.FC<IAppProviderProps> = ({ children }) => {

    const [state, dispatch] = useReducer(appReducer, {} as InitialState);

    return (
        <AppContext.Provider value={{ state, dispatch }}>
            {children}
        </AppContext.Provider>
    );
}

export { AppContext, AppProvider };
