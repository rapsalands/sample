export interface IAppProviderProps {

}

export interface ICreateContext {
    state: InitialState,
    dispatch: DispatchType
}

export interface InitialState {
    userInfo: UserInfo | null
}

export type DispatchType = (param: DispatchParamType) => void;

export type DispatchParamType = DispatchTypeSignin;

export type DispatchTypeSignin = {
    type: 'signin',
    data: UserInfo | null
}

export interface UserInfo {
    userId: string,
    firstName: string,
    lastName: string
}
