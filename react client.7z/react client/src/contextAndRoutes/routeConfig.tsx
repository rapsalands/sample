import { Switch, Route, Redirect } from 'react-router-dom';
import Homepage from '../components/home/homepage';
import SignIn from '../components/home/signin';
import ErrorPage from '../error/errorPage';

const RouteConfig = (props: any) => {

    return (
        <Switch>
            <Route exact path="/signin" component={SignIn} />
            <Route exact path="/" component={Homepage} />
            <Route exact path="/error" component={ErrorPage} />
            <Redirect to="/error" />
        </Switch>
    );
};

export default RouteConfig;
