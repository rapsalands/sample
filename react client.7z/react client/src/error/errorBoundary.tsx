import React from 'react';
import { isEqual } from 'lodash';
import Routes from '../contextAndRoutes/routes';
import { AppContext } from '../contextAndRoutes/appContext';

class ErrorBoundary extends React.Component {
    constructor(props: any) {
        super(props);
        this.state = {
            error: null,
            info: null
        };
    }

    static contextType = AppContext;

    componentDidCatch(error, info) {

        //@ts-ignore
        if (isEqual(error, this.state.error)) return;

        this.setState({ error, info });
        //httpService.post(errorUrl, { error, info });
    }

    render() {
        // @ts-ignore
        if (this.state.info) {
            window.location.replace(Routes.error);
            return;
        }

        return (
            this.props.children
        );
    }
}

export default ErrorBoundary;
