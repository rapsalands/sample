import { Box, Link, makeStyles, Typography } from '@material-ui/core';
import React, { SyntheticEvent } from 'react';
import Routes from '../contextAndRoutes/routes';
import { useHistory } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    text: {
        margin: theme.spacing(4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'left'
    },
    redirect: {
        margin: theme.spacing(4),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        cursor: 'pointer'
    }
}));

const ErrorPage = () => {

    const classes = useStyles();
    const history = useHistory();

    function goHome(e: SyntheticEvent) {
        history.push(Routes.home);
        e.preventDefault();
    }

    return (
        <Box>
            <Typography variant='h2' className={classes.text}>ugh! something went wrong :(</Typography>
            <Typography variant='h5' className={classes.text}>Sorry for inconvience</Typography>
            <Typography onClick={goHome} className={classes.redirect}>
                <Link href="#" onClick={goHome}>
                    Go to home
                </Link>
            </Typography>
        </Box >
    );
};

export default ErrorPage;
