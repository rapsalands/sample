﻿using Business;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Models.Models;
using Moq;
using Repository.Interfaces;
using ServiceAPI.Controllers;
using System.Threading.Tasks;
using UnitTests.Mocks;
using Xunit;

namespace UnitTests.IntegrationTests
{
    public class ProductControllerTests : BaseTests
    {
        private ProductMocks productMock;
        private ProductController ins;

        public ProductControllerTests()
        {
            productMock = new ProductMocks();
            ins = GetInstance(() => controller());
        }

        ProductController controller() => new ProductController(GetService<IProductService>());

        [Fact]
        public void GetByIdTest1()
        {
            var result = Execute<OkObjectResult>(() => ins.GetById(4));
            Assert.NotNull(result);
            var value = result.Value as Product;
            Assert.True(value.Id == 4);
        }

        [Fact]
        public void GetByIdTest2()
        {
            var result = Execute<OkObjectResult>(() => ins.GetById(-1));
            Assert.NotNull(result);
            Assert.True(result.StatusCode == 200);
            Assert.Null(result.Value);
        }

        [Fact]
        public void UpdateTest1()
        {
            var result = Execute<BadRequestObjectResult>(() => ins.Update(null));
            Assert.NotNull(result);
            Assert.True(result.StatusCode == 400);
        }

        [Fact]
        public void UpdateTest2()
        {
            var product = new Product
            {
                Id = 4,
                Name = "Name Modified",
                Description = "Desc Modified"
            };

            IProductRepository mock(IServiceCollection services) => productMock.Create(product);
            ins = GetInstance(controller, (services) => mock(services));

            var result = Execute<OkObjectResult>(() => ins.Update(product));
            Assert.NotNull(result);

            var value = (int)result.Value;
            Assert.True(value == 1);

            var repo = GetService<IProductRepository>();

            var item = repo.GetByIdAsync(4).Result;
            Assert.True(item.Name == "Name Modified");
            Assert.True(item.Description == "Desc Modified");
        }

        [Fact]
        public void AddTest1()
        {
            var result = Execute<BadRequestObjectResult>(() => ins.Add(null));
            Assert.NotNull(result);
            Assert.True(result.StatusCode == 400);
        }
    }
}
