﻿using Models.Models;
using Moq;
using Repository.Interfaces;
using System.Threading.Tasks;

namespace UnitTests.Mocks
{
    public class ProductMocks
    {
        internal IProductRepository Create(Product product)
        {
            var mock = new Mock<IProductRepository>();
            mock.Setup(n => n.UpdateAsync(It.IsAny<Product>())).Returns(() => Task.FromResult(1));
            mock.Setup(n => n.GetByIdAsync(It.IsAny<int>())).Returns(Task.FromResult(product));
            return mock.Object;
        }
    }
}
