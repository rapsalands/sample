﻿using System;
using ServiceAPI;
using Models.Dtos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace UnitTests
{
    public class BaseTests : IDisposable
    {
        private IServiceProvider ServiceProvider;

        internal T GetInstance<T>(Func<T> instance, Action<IServiceCollection> services = null)
        {
            Setup(services);
            return instance();
        }

        private void Setup(Action<IServiceCollection> configureServices = null)
        {
            ServiceProvider = Program.CreateHostBuilder(Array.Empty<string>())
                .ConfigureServices((a, b) =>
                {
                    b.AddOptions();
                    b.AddOptions<AppSettings>();
                })
                .ConfigureServices((hostingContext, services) =>
                {
                    configureServices?.Invoke(services);
                })
                .ConfigureAppConfiguration((a, b) =>
                {
                    b.AddJsonFile("appsettings.json")
                        .AddJsonFile("appsettings.development.json")
                        .AddJsonFile("appsettings.test.json");
                })
                .Build().Services; // one liner
        }

        public T GetService<T>() where T : class => ServiceProvider.GetService<T>();

        public K Execute<K>(Func<Task<IActionResult>> func) where K : ObjectResult
        {
            var result = func().ConfigureAwait(true).GetAwaiter().GetResult();
            K okResult = (K) result;
            return okResult;
        }

        public void Dispose()
        {
        }
    }
}
