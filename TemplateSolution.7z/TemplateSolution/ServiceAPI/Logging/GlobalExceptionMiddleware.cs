﻿using Business.Helpers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace ServiceAPI.Logging
{
    public class GlobalExceptionMiddleware : IMiddleware
    {
        private readonly ILogger<GlobalExceptionMiddleware> logger;
        private readonly IFireForgetService fireForgetService;

        public GlobalExceptionMiddleware(ILogger<GlobalExceptionMiddleware> logger, IFireForgetService fireForgetService)
        {
            this.logger = logger;
            this.fireForgetService = fireForgetService;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (Exception exception)
            {
                fireForgetService.Execute(() => logger.LogError(exception, exception.Message));
            }
        }
    }

    public static class GlobalExceptionMiddlewareExtentions
    {
        public static IApplicationBuilder UseGlobalExceptionMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GlobalExceptionMiddleware>();
        }
    }
}
