﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceAPI.Logging
{
    public class LogSetupMiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            string userAgent = "", userId = "", url = "";

            if(context.Request.HttpContext != null)
            {
                userAgent = context.Request.HttpContext.Request.Headers["User-Agent"];
                userId = context.Request.HttpContext.Request.Headers["UserId"].FirstOrDefault();
                url = UriHelper.GetDisplayUrl(context.Request);
            }

            MappedDiagnosticsContext.Set("userAgent", userAgent);
            MappedDiagnosticsContext.Set("correlationId", Guid.NewGuid());
            MappedDiagnosticsContext.Set("userId", userId);
            MappedDiagnosticsContext.Set("url", url);

            await next(context);
        }
    }

    public static class LogSetupMiddlewareExtensions
    {
        public static IApplicationBuilder UseLogSetupMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LogSetupMiddleware>();
        }
    }
}
