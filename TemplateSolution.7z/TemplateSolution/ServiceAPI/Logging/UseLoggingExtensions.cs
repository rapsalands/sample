﻿using Microsoft.AspNetCore.Builder;

namespace ServiceAPI.Logging
{
    public static class UseLoggingExtensions
    {
        public static void UseLoggingFeature(this IApplicationBuilder app)
        {
            app.UseLogSetupMiddleware();
            app.UseMiddleware<GlobalExceptionMiddleware>();

            app.UseWhen(context => context.Request.Path.StartsWithSegments("/api"), appBuilder =>
            {
                appBuilder.UseMiddleware<RequestLoggingMiddleware>();
                appBuilder.UseMiddleware<ResponseLoggingMiddleware>();
            });
        }
    }
}
