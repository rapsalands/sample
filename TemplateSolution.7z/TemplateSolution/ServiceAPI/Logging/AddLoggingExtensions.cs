﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceAPI.Logging
{
    public static class AddLoggingExtensions
    {
        public static void AddLoggingMiddlewares(this IServiceCollection services)
        {
            services.AddScoped<LogSetupMiddleware>();
            services.AddScoped<GlobalExceptionMiddleware>();
            services.AddScoped<RequestLoggingMiddleware>();
            services.AddScoped<ResponseLoggingMiddleware>();
        }
    }
}
