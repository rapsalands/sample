﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ServiceAPI.Extension
{
    public static class ConfigureCorsExtension
    {
        public static void ConfigureCors(this IServiceCollection services, IConfiguration configuration, string sectionName, string policyName)
        {
            var corsOrigins = configuration.GetSection(sectionName).Get<string[]>();
            services.AddCors(options =>
            {
                options.AddPolicy(policyName, builder =>
                    builder.AllowAnyOrigin().WithOrigins(corsOrigins)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                );
            });
        }
    }
}
