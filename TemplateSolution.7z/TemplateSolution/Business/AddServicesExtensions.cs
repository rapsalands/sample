﻿using Business.Helpers;
using Business.Validations;
using Microsoft.Extensions.DependencyInjection;

namespace Business
{
    public static class AddServicesExtensions
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<IProductService, ProductService>();
            services.AddScoped<IFireForgetService, FireForgetService>();
            services.AddScoped<ValidationService>();
        }
    }
}
