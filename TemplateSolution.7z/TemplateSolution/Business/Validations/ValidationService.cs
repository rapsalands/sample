﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Business.Validations
{
    public class ValidationService
    {
        const string argumentNull = "Passed argument cannot be null.";

        public void AssertProduct(Product product, string message = null)
        {
            if (product == null) throw new ArgumentNullException(message ?? argumentNull);
        }

        public void AssertProduct<T>(Product product, string message = null) where T : Exception, new()
        {
            if (product == null) throw (T) Activator.CreateInstance(typeof(T), message ?? argumentNull);
        }
    }
}
