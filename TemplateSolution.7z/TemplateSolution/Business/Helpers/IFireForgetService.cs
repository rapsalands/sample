﻿using System;
using System.Threading.Tasks;

namespace Business.Helpers
{
    public interface IFireForgetService
    {
        void Execute(Func<Task> job);
        void Execute(Action job);
        void Execute<T>(Func<T, Task> job);
    }
}