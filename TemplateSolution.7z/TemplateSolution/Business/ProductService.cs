﻿using Business.Validations;
using Models.Models;
using Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository productRepository;
        private readonly ValidationService validationService;

        public ProductService(IProductRepository productRepository, ValidationService validationService)
        {
            this.productRepository = productRepository;
            this.validationService = validationService;
        }

        public async Task<Product> Get(int id)
        {
            return await productRepository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Product>> GetAll()
        {
            return await productRepository.GetAllAsync();
        }

        public async Task<int> Update(Product product)
        {
            validationService.AssertProduct(product);
            return await productRepository.UpdateAsync(product);
        }

        public async Task<int> Delete(int id)
        {
            return await productRepository.DeleteAsync(id);
        }

        public async Task<int> Add(Product product)
        {
            validationService.AssertProduct(product);
            return await productRepository.AddAsync(product);
        }
    }
}
