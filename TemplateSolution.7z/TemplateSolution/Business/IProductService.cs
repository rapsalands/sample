﻿using Models.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business
{
    public interface IProductService
    {
        Task<int> Add(Product product);
        Task<int> Delete(int id);
        Task<IEnumerable<Product>> GetAll();
        Task<Product> Get(int id);
        Task<int> Update(Product product);
    }
}