﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.Dtos
{
    public class AppSettings
    {
        public Logging RequestLogging { get; set; }
        public Logging ResponseLogging { get; set; }
    }

    public class Logging
    {
        public bool Active { get; set; }
    }
}
