﻿using Dapper;
using Models.Models;
using Repository.Interfaces;
using Repository.Queries;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Repository.Implementation
{
    public class ProductRepository : IProductRepository
    {
        private readonly SqlConnection sqlConnection;
        private readonly ProductQuery productQuery;

        public ProductRepository(SqlConnection sqlConnection, ProductQuery productQuery)
        {
            this.sqlConnection = sqlConnection;
            this.productQuery = productQuery;
        }

        public async Task<int> AddAsync(Product product)
        {
            product.AddedOn = DateTime.Now;
            var queryParam = productQuery.AddProduct(product);
            var result = await sqlConnection.ExecuteAsync(queryParam.Query, queryParam.Param);
            return result;
        }

        public async Task<int> DeleteAsync(int id)
        {
            var queryParam = productQuery.DeleteProduct(id);
            var result = await sqlConnection.ExecuteAsync(queryParam.Query, queryParam.Param);
            return result;
        }

        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            var queryParam = productQuery.GetProducts();
            var result = await sqlConnection.QueryAsync<Product>(queryParam.Query, queryParam.Param);
            return result.ToList();
        }

        public async Task<Product> GetByIdAsync(int id)
        {
            var queryParam = productQuery.GetProduct(id);
            var result = await sqlConnection.QuerySingleOrDefaultAsync<Product>(queryParam.Query, queryParam.Param);
            return result;
        }

        public async Task<int> UpdateAsync(Product product)
        {
            product.ModifiedOn = DateTime.Now;
            var queryParam = productQuery.UpdateProduct(product);
            var result = await sqlConnection.ExecuteAsync(queryParam.Query, queryParam.Param);
            return result;
        }
    }
}
