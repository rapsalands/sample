﻿using Models.Models;

namespace Repository.Queries
{
    public class ProductQuery
    {
        public QueryParam GetProduct(int id)
        {
            var query = "select * from Products where Id = @Id";
            var param = new { id };
            return new QueryParam(query, param);
        }

        public QueryParam GetProducts() => new QueryParam("select * from Products");

        public QueryParam UpdateProduct(Product product)
        {
            var query = "UPDATE Products SET Name = @Name, Description = @Description, Barcode = @Barcode, Rate = @Rate, ModifiedOn = @ModifiedOn  WHERE Id = @Id";
            return new QueryParam(query, product);
        }

        public QueryParam DeleteProduct(int id)
        {
            var query = "DELETE FROM Products WHERE Id = @id";
            return new QueryParam(query, new { id });
        }

        public QueryParam AddProduct(Product product)
        {
            var query = "Insert into Products (Name,Description,Barcode,Rate,AddedOn) VALUES (@Name,@Description,@Barcode,@Rate,@AddedOn)";
            return new QueryParam(query, product);
        }
    }
}
