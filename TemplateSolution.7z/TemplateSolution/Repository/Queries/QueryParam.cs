﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Repository.Queries
{
    public class QueryParam
    {
        public QueryParam(string query = "", object param = null)
        {
            Query = query;
            Param = param;
        }

        public string Query { get; }
        public object Param { get; }
    }
}
