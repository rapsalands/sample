﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Repository.Implementation;
using Repository.Interfaces;
using Repository.Queries;
using System.Data.SqlClient;

namespace Repository
{
    public static class AddRepositoryExtensions
    {
        public static void AddRepositories(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<SqlConnection>(options =>
            {
                return new SqlConnection(configuration.GetConnectionString("AppData"));
            });

            services.AddScoped<IProductRepository, ProductRepository>();
            
            services.AddScoped<ProductQuery>();
        }
    }
}
