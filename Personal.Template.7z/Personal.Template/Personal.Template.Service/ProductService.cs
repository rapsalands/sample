﻿using Personal.Template.Interface.Repository;
using Personal.Template.Interface.Service;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
namespace Personal.Template.Service
{
    public class BaseService<T, U> : IBaseService<T, U>
        where T : class
        where U : class
    {
        private readonly IBaseRepository<U> baseRepository;
        private readonly IMapper mapper;
        public BaseService(IBaseRepository<U> baseRepository, IMapper mapper)
        {
            this.baseRepository = baseRepository;
            this.mapper = mapper;
        }

        public async Task<T> AddAsync(U dto)
        {
            var addedId = await this.baseRepository.AddAsync(dto);
            return this.mapper.Map<T>(await this.baseRepository.GetByIdAsync(addedId));
        }

        public async Task<int> DeleteAsync(int id)
        {
            return await this.baseRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return this.mapper.Map<IEnumerable<T>>(await this.baseRepository.GetAllAsync());
        }

        public async Task<T> GetByIdAsync(int id)
        {
            return this.mapper.Map<T>(await this.baseRepository.GetByIdAsync(id));
        }

        public async Task<int> UpdateAsync(U dto)
        {
            return await this.baseRepository.UpdateAsync(dto);
        }
    }
}
