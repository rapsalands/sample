﻿using Microsoft.Extensions.DependencyInjection;
using Personal.Template.Interface.Service;
using System;
using System.Threading.Tasks;

namespace Personal.Template.Service
{
    public class FireForgetService : IFireForgetService
    {
        private readonly IServiceProvider serviceProvider;

        public FireForgetService(IServiceProvider serviceProvider)
        {
            this.serviceProvider = serviceProvider;
        }

        public void Execute<T>(Func<T, Task> job)
        {
            Task.Run(async () =>
            {
                var param = serviceProvider.GetRequiredService<T>();
                await job(param);
            });
        }

        public void Execute(Func<Task> job)
        {
            Task.Run(async () =>
            {
                await job();
            });
        }

        public void Execute(Action job)
        {
            Task.Run(() =>
            {
                job();
            });
        }
    }
}
