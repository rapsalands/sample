﻿namespace Personal.Template.Model.Others
{
    public class AppSettings
    {
        public Logging RequestLogging { get; set; }
        public Logging ResponseLogging { get; set; }
    }
}
