﻿namespace Personal.Template.Model.Others
{
    public class Logging
    {
        public bool Active { get; set; }
    }
}
