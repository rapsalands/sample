﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Personal.Template.Model.Others;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Personal.Template.Api.Middleware
{
    public class RequestLoggingMiddleware : IMiddleware
    {
        private readonly AppSettings appSettings;
        private readonly ILogger<RequestLoggingMiddleware> logger;

        public RequestLoggingMiddleware(ILogger<RequestLoggingMiddleware> logger, IOptions<AppSettings> options)
        {
            appSettings = options.Value;
            this.logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            if (!appSettings.RequestLogging.Active)
            {
                await next(context);
                return;
            }

            string requestBody = await ReadRequestBody(context.Request);

            var message = $"REQUEST_{requestBody}";
            logger.LogInformation(message);

            await next(context);
        }

        private async Task<string> ReadRequestBody(HttpRequest request)
        {
            request.EnableBuffering();

            using var reader = new StreamReader(request.Body, Encoding.UTF8, true, 1024, true);
            var result = await reader.ReadToEndAsync();

            request.Body.Position = 0;
            return result;
        }
    }
}
