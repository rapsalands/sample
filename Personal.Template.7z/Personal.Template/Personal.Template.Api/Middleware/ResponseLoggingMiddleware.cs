﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Personal.Template.Model.Others;
using System.IO;
using System.Threading.Tasks;

namespace Personal.Template.Api.Middleware
{
    public class ResponseLoggingMiddleware : IMiddleware
    {
        private readonly AppSettings appSettings;
        private readonly ILogger<ResponseLoggingMiddleware> logger;

        public ResponseLoggingMiddleware(ILogger<ResponseLoggingMiddleware> logger, IOptions<AppSettings> options)
        {
            appSettings = options.Value;
            this.logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            var response = context.Response;

            if (!appSettings.ResponseLogging.Active)
            {
                await next(context);
                return;
            }

            var original = context.Response.Body;
            using var responseBodyStream = new MemoryStream();
            context.Response.Body = responseBodyStream;

            await next(context);

            var responseBody = await ReadResponseBody(response);

            var message = $"RESPONSE_{responseBody}";
            logger.LogInformation(message);

            await responseBodyStream.CopyToAsync(original);
        }

        private async Task<string> ReadResponseBody(HttpResponse response)
        {
            response.Body.Seek(0, SeekOrigin.Begin);
            string text = await new StreamReader(response.Body).ReadToEndAsync();
            response.Body.Seek(0, SeekOrigin.Begin);
            return text;
        }
    }
}
