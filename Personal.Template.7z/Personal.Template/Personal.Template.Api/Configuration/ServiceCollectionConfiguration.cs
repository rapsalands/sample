﻿using Microsoft.Extensions.DependencyInjection;
using Personal.Template.Api.Middleware;
using Personal.Template.Interface.Repository;
using Personal.Template.Interface.Service;
using Personal.Template.Model.Model;
using Personal.Template.Repository;
using Personal.Template.Service;

namespace Personal.Template.Api.Configuration
{
    public static class ServiceCollectionConfiguration
    {
        public static void AddMiddlewares(this IServiceCollection services)
        {
            services.AddScoped<LogSetupMiddleware>();
            services.AddScoped<GlobalExceptionMiddleware>();
            services.AddScoped<RequestLoggingMiddleware>();
            services.AddScoped<ResponseLoggingMiddleware>();
        }

        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<IProductService, ProductService>();
            services.AddScoped<IFireForgetService, FireForgetService>();
        }

        public static void AddRepositories(this IServiceCollection services)
        {
            services.AddScoped<IProductRepository<Product>, ProductRepository>();
        }
    }
}
