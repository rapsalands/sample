﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Personal.Template.Model.DTO;
using Personal.Template.Model.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Personal.Template.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : BaseController<ProductDTO, Product>
    {
        
    }
}
