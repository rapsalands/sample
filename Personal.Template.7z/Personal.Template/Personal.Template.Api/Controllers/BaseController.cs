﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Personal.Template.Interface.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Personal.Template.Api.Controllers
{
    public class BaseController<T, U> : ControllerBase
        where T: class
        where U: class
    {
        protected readonly IBaseService<T, U> baseService;
    }
}
