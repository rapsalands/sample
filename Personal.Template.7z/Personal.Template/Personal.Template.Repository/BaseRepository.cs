﻿using Dapper;
using Personal.Template.Interface.DBHelper;
using Personal.Template.Interface.Repository;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Personal.Template.Repository
{
    public class BaseRepository<U> : IBaseRepository<U>
        where U : class
    {
        private readonly SqlConnection dbConnection;
        private readonly IDbHelper<U> dbHelper;
        public BaseRepository(SqlConnection dbConnection, IDbHelper<U> dbHelper)
        {
            this.dbConnection = dbConnection;
            this.dbHelper = dbHelper;
        }

        public async Task<int> AddAsync(U entity)
        {
            throw new System.NotImplementedException();
        }

        public async Task<int> DeleteAsync(int id)
        {
            throw new System.NotImplementedException();
        }

        public async Task<IEnumerable<U>> GetAllAsync()
        {
            var queryParam = this.dbHelper.GetAllQuery();
            return await this.dbConnection.QueryAsync<U>(queryParam, null);
        }

        public async Task<U> GetByIdAsync(int id)
        {
            throw new System.NotImplementedException();
        }

        public async Task<int> UpdateAsync(U entity)
        {
            throw new System.NotImplementedException();
        }
    }
}
