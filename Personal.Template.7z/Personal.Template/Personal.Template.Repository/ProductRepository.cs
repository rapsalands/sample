﻿using Dapper;
using Personal.Template.Interface.DBHelper;
using Personal.Template.Interface.Repository;
using Personal.Template.Model.Model;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Personal.Template.Repository
{
    public class ProductRepository : BaseRepository<Product>, IProductRepository<Product>
    {
        public ProductRepository(SqlConnection sqlConnection, IDbHelper<Product> dbHelper) : base(sqlConnection, dbHelper)
        {
        }
    }
}
