﻿using Personal.Template.Interface.DBHelper;
using System;
using System.Collections.Generic;
using System.Text;

namespace Personal.Template.Repository
{
    class DbHelper<T> : IDbHelper<T>
        where T : class
    {
        public string AddQuery(T entity)
        {
            throw new NotImplementedException();
        }

        public string DeleteQuery(int id)
        {
            throw new NotImplementedException();
        }

        public string GetAllQuery()
        {
            return $"SELECT * FROM {typeof(T).Name} (NOLOCK)";
        }

        public string GetByIdQuery(int id)
        {
            throw new NotImplementedException();
        }

        public string UpdateQuery(T entity)
        {
            throw new NotImplementedException();
        }
    }
}
