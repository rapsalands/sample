using System;
using Xunit;

namespace Personal.Template.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
