﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Personal.Template.Interface.Service
{
    public interface IBaseService<T, U>
        where T: class
        where U: class
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIdAsync(int id);
        Task<T> AddAsync(U dto);
        Task<int> UpdateAsync(U dto);
        Task<int> DeleteAsync(int id);
    }
}
