﻿using System;
using System.Threading.Tasks;

namespace Personal.Template.Interface.Service
{
    public interface IFireForgetService
    {
        void Execute(Func<Task> job);
        void Execute(Action job);
        void Execute<T>(Func<T, Task> job);
    }
}
