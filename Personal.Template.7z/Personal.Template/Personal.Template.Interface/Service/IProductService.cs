﻿using Personal.Template.Model.DTO;
using Personal.Template.Model.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Personal.Template.Interface.Service
{
    public interface IProductService: IBaseService<ProductDTO, Product>
    {
    }
}
