﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Personal.Template.Interface.DBHelper
{
    public interface IDbHelper<T>
        where T: class
    {
        string GetByIdQuery(int id);
        string GetAllQuery();
        string AddQuery(T entity);
        string UpdateQuery(T entity);
        string DeleteQuery(int id);
    }
}
