﻿using Personal.Template.Model.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Personal.Template.Interface.Repository
{
    public interface IProductRepository<U> : IBaseRepository<U>
        where U: class
    {
    }
}
