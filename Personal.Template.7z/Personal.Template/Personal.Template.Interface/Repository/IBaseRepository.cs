﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Personal.Template.Interface.Repository
{
    public interface IBaseRepository<U>
        where U : class
    {
        Task<U> GetByIdAsync(int id);
        Task<IEnumerable<U>> GetAllAsync();
        Task<int> AddAsync(U entity);
        Task<int> UpdateAsync(U entity);
        Task<int> DeleteAsync(int id);
    }
}
